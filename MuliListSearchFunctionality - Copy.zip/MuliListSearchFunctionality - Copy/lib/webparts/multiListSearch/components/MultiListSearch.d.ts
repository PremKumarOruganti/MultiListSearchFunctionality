/// <reference types="react" />
declare const MultiListSearch: () => JSX.Element;
export default MultiListSearch;
//# sourceMappingURL=MultiListSearch.d.ts.map