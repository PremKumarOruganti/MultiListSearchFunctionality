declare const styles: {
    multiListSearch: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=MultiListSearch.module.scss.d.ts.map