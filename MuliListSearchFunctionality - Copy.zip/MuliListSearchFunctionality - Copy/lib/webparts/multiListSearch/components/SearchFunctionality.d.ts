/// <reference types="react" />
declare const SearchFunctionality: () => JSX.Element;
export default SearchFunctionality;
//# sourceMappingURL=SearchFunctionality.d.ts.map