/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
import * as React from 'react';
import { useState, useEffect } from 'react';
import { sp } from "@pnp/sp/presets/all";

// interface ISearchFunctionalityProps {
//     context: any; // Ideally, use WebPartContext from @microsoft/sp-webpart-base
// }

const SearchFunctionality = () => {


    const [searchText, setSearchText] = useState('');
    const [results, setResults] = useState<any[]>([]);

    useEffect(() => {
        sp.setup({
            sp: {
                baseUrl: "https://mrxcoder.sharepoint.com/sites/Test1"
            }
        });
    }, []);


    const fetchItems = async (searchText: string) => {
        const list1Items = (await sp.web.lists.getByTitle("ForFilterTest1")
            .items.filter(`substringof('${searchText}',FirstName)`).get())
            .map(item => ({ ...item, SourceList: 'ForFilterTest1' }))

        const list2Items = (await sp.web.lists.getByTitle("ForFilterTest2")
            .items.filter(`substringof('${searchText}',FirstName)`).get())
            .map(item => ({ ...item, SourceList: 'ForFilterTest2' }))

        return [...list1Items, ...list2Items];
    };

    const handleSearch = async () => {
        const items = await fetchItems(searchText);
        console.log("Fetched Items: ", items);

        setResults(items);
    };

    return (
        <>
            <div>Search Functionality dsd</div>
            <input
                type='text'
                value={searchText}
                onChange={(e) => setSearchText(e.target.value)}
                placeholder='Search...'
            />
            <button onClick={handleSearch}>Search</button>

            <ul>
                {
                    results.map((item, index) => (
                        <li key={index}>{item.FirstName} &nbsp;  {` & it is 'from the list'`} {item.SourceList}</li>
                    ))
                }
            </ul>
        </>
    );
};

export default SearchFunctionality;
