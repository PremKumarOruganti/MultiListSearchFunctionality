/* tslint:disable */
require("./MultiListSearch.module.css");
const styles = {
  multiListSearch: 'multiListSearch_33640e82',
  teams: 'teams_33640e82',
  welcome: 'welcome_33640e82',
  welcomeImage: 'welcomeImage_33640e82',
  links: 'links_33640e82'
};

export default styles;
/* tslint:enable */